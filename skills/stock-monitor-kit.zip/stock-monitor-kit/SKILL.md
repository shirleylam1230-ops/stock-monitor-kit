---
name: stock-monitor-kit
description: 个人股票投资自动化监控套件——为用户从零搭建一套完整的投资监控与日报系统：持仓/观察池 MACD 技术面分析、宏观微观指标趋势、FOMC 与金十财经日历、关注博主（抖音/小红书/微博/雪球）T-1 更新追踪，产出多屏网页 App 并每工作日 08:00/19:00 邮件推送。当用户要求「搭建股票投资监控」「做投资日报」「持仓分析自动化」「关注博主动态监测」或想复刻类似系统时使用本技能。
agent_created: true
---

# Stock Monitor Kit · 股票投资监控套件

## Overview

把一个已验证跑通的个人投资监控系统部署到新用户环境。系统包含四个板块：

1. **持仓分析**——一票一卡，MACD 五级趋势判定（强势上行/低位转强/多头蓄势/多头区走弱/空头趋势）+ 背离检测
2. **观察池**——标的池 + 科技对冲组（红利/创新药/煤炭），MACD 走向一览
3. **宏观微观监测**——美债利差/美元/VIX/CPI/PMI/M1M2/社融/LPR 历史趋势图 + FOMC/金十大事日历
4. **博主动态**——T-1 窗口更新检测、改名检测、抖音视频 AI 章节要点总结

产出：5 屏网页 App（首页/持仓/宏观/博主/归档）+ 邮件摘要推送，两个工作日定时任务自动刷新。

本技能随附 12 个可直接运行的 Python 脚本（`scripts/`），不含任何前一个用户的个人数据。

## 部署流程（新用户从零到上线）

**开始前先读 `references/pitfalls.md`**——里面有大量实测踩坑结论（平台可用性、风控、数据源限制），能避免返工。

按 `references/setup-guide.md` 逐步执行，核心顺序：

1. **收集用户信息**（持仓/观察池/邮箱/关注博主/推送时间）——guide 第 0 节有逐项问法
2. **建项目目录 + 云数据库四张表**（holdings / watchlist / creators / snapshots）
3. **导入个人数据**——博主清单写 `data/creators.json` + 云端 creators 表；持仓写云端表
4. **Python 环境**——常规脚本用系统 python3；浏览器脚本需 venv + websocket-client
5. **登录态**——自动拉起真实 Chrome（调试端口 9222，独立配置目录），用户手动登录 weibo / 金十各一次
6. **首次跑通验收**——guide 第 5 节有完整命令序列，产物五页 HTML 人工检查
7. **发布应用 + 建两个定时任务**（工作日 08:00 隔夜版 / 19:00 盘后版，提示词模板在 guide 第 6 节）
8. **交付确认清单**——guide 第 7 节逐项核对

## 日常运行（系统搭好之后）

- **改持仓/观察池**：用户在对话里说（如"某标的减 2000 股"）→ 直接改云端表，下次定时任务自动生效（任务开头会把云端表镜像到 data/positions.json）
- **加/删关注博主**：改 `data/creators.json` + 云端 creators 表（两边同步），enabled 字段控制启停
- **登录态过期**：脚本返回 `login_required` 时，列出具体平台让用户在调试 Chrome 里重新登录
- **临时提问**（"XX 股票最近怎么样"）：直接用 westock CLI 现查，不必等日报

## 关键约定

- 涨红跌绿（A 股惯例）：涨 #C62828 / 跌 #2E7D32
- 负成本价（做 T 摊薄）是正确数据不要"修正"，但不计入累计盈亏
- 日报只讲差分（相对上次的变化）
- 数据取不到必须标注「本次未取到」+ 原因，不许编造
- 一切产出注明「不构成投资建议」

## Resources

- `scripts/` — 12 个生产级 Python 脚本，直接复制到用户项目：
  - 数据采集：`westock_client.py`（行情 CLI 封装）、`fetch_technical.py`、`fetch_daily.py`、`fetch_macro_history.py`、`fetch_fomc.py`、`fetch_jin10.py`（登录态）、`fetch_social.py`（登录态、四平台）
  - 分析：`macd.py`（五级判定 + 背离）
  - 浏览器：`cdp.py`（真实 Chrome CDP 客户端，防无头检测，含标签页泄漏修复）
  - 产出：`build_daily_report.py`、`build_holdings_report.py`、`build_app.py`
- `references/setup-guide.md` — 部署手册（信息收集话术、建表 SQL、命令序列、定时任务提示词模板、交付清单）
- `references/pitfalls.md` — 踩坑记录（公众号不可行的原因、风控对策、数据源限制、工程稳定性）
- `references/README.md` — 项目结构总览（可发给用户看）
