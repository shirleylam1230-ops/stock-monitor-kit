# 部署指南：给新用户搭一套股票投资监控

本文是完整的逐步操作手册。执行时按顺序进行，每步完成后向用户确认再进入下一步。

## 0. 需要向用户收集的信息（开始前一次性问清）

| 信息 | 用途 | 示例问法 |
|---|---|---|
| 持仓明细 | holdings 表 | 「发我一份持仓 Excel 或直接打字：代码/名称/股数/成本价」 |
| 观察池标的 | watchlist 表 | 「有哪些在观察但还没买的？想要对冲标的吗（红利/创新药/煤炭等）」 |
| 收件邮箱 | 邮件推送 | 「日报推送到哪个邮箱？」 |
| 关注博主 | creators.json + creators 表 | 「抖音号/小红书号/微博主页/雪球主页，各列一下」 |
| 报告语言与推送时间 | 自动化任务 | 「每天几点推送？隔夜版+盘后版可以吗」 |

成本价允许负数（做 T 摊薄），**不要"修正"它**，但汇总时负成本标的不计入累计盈亏。

## 1. 建项目目录与云数据库

1. 建目录 `<项目>/scripts`、`<项目>/data`、`<项目>/reports`。
2. 把本技能 `scripts/` 下的 12 个 `.py` 复制到 `<项目>/scripts/`。
3. 开通 WorkBuddy 云服务，建四张表（RLS 开启，owner_id 默认用户标识）：

```sql
holdings(id, market, code, name, asset_type, shares, cost_price, currency, note, created_at, updated_at)
watchlist(id, market, code, name, asset_type, tags, reason, note, created_at, updated_at)
creators(id, platform, platform_uid, name, nickname, home_url, note, enabled, created_at, updated_at)
snapshots(id, snap_date, payload_json, created_at)
```

`market` 取值 cn / hk / us；`code` 形如 sz300308 / sh600519 / hk00700 / usNVDA。

## 2. 导入个人数据

1. 持仓/观察池：解析用户输入写入 holdings / watchlist 表。
2. 博主清单：写 `<项目>/data/creators.json`，格式：

```json
[
  {"platform": "douyin", "platform_uid": "抖音号", "note": "昵称", "enabled": true},
  {"platform": "xhs",    "platform_uid": "小红书号", "note": "", "enabled": true},
  {"platform": "xueqiu", "platform_uid": "雪球数字ID", "note": "", "enabled": true},
  {"platform": "weibo",  "platform_uid": "微博主页数字ID", "note": "", "enabled": true}
]
```

同时把同一份清单写入云端 creators 表。platform 取值只有 douyin/xhs/xueqiu/weibo 四种（公众号不支持，见 pitfalls.md）。

## 3. Python 环境

两个解释器：
- **常规脚本**（westock_client / fetch_technical / fetch_daily / fetch_fomc / fetch_macro_history / build_*）：系统 python3 即可。
- **浏览器脚本**（cdp / fetch_jin10 / fetch_social）：需要 `websocket-client`。装到隔离 venv：

```bash
python3 -m venv <venv路径> && <venv>/bin/pip install websocket-client
```

## 4. 登录态准备（关键步骤，需用户配合）

1. 首次运行任一浏览器脚本会自动拉起一个真实 Chrome（调试端口 9222，独立配置目录，**不影响用户主浏览器**）。
2. 在弹出的窗口里让用户手动登录一次：`weibo.com`、`rili.jin10.com`；抖音/小红书有登录态更稳（游客可看部分内容但风控更严）。
3. 若用户主 Chrome 已登录且愿意，可先完全退出主 Chrome，再运行 `python scripts/cdp.py --sync` 复制登录态。
4. 登录态过期表现：脚本返回 `login_required`。提示用户重新扫码即可，不要重试超过 2 次。

## 5. 首次跑通（验收）

```bash
cd <项目>
python3 scripts/fetch_technical.py --asof <今天> --start <90天前> --limit 60
python3 scripts/fetch_fomc.py --today <今天>
<venv-python> scripts/fetch_jin10.py --date <今天> --days 5
<venv-python> scripts/fetch_social.py --date <今天> --max-items 3
python3 scripts/fetch_daily.py --date <今天>
python3 scripts/fetch_macro_history.py --date <今天>
# 云端查询 holdings/watchlist → 写 data/positions.json（结构见 README）
python3 scripts/build_daily_report.py --date <今天> --mode evening
python3 scripts/build_app.py --date <今天>
```

产物在 `reports/`：index / holdings / macro / social / archive 五页 + daily-YYYYMMDD.html。人工检查无误后发布。

## 6. 发布与定时任务

1. 用应用发布能力把 `reports/` 发布为静态站（entryHtml=index.html）。
2. 建两个工作日定时任务（自动化），提示词模板：

**08:00 隔夜版**（重点：隔夜美股/海外宏观/当日事件）与 **19:00 盘后版**（重点：A 股收盘/博主 T-1/技术差分），步骤均为：

```
1. fetch_technical.py --asof <D> --start <90天前> --limit 60
2. fetch_fomc.py --today <D>
3. fetch_jin10.py --date <D> --days 3~5（隔夜3盘后5）
4. fetch_social.py --date <D> --max-items 3
5. fetch_daily.py --date <D>
6. fetch_macro_history.py --date <D>
7. 云端查 holdings/watchlist → 覆盖 data/positions.json
8. build_daily_report.py --date <D> --mode morning|evening
9. build_app.py --date <D>
10. 重新发布 reports/ + 邮件摘要推送到用户邮箱
```

## 7. 交付确认清单

- [ ] 线上五页可访问，数据是用户自己的
- [ ] 测试邮件已收到
- [ ] 两个定时任务已激活（工作日）
- [ ] 用户知道：改持仓/博主就在对话框说，会同步云端与配置
- [ ] 用户知道：哪些平台需要登录态、过期了怎么办
